from __future__ import print_function

import json
from pprint import pprint
import urllib
import boto3
from botocore.exceptions import ClientError
import paramiko

print('Loading function')

# ---------------------------------------------------------------------------
# Global Variables
# ---------------------------------------------------------------------------
s3 = boto3.client('s3')
gpdb_host = ''
email_sender = ''
email_recipient = ''
aws_region = ''
config_dir = 'sandbox/config/'
script = ''

# ---------------------------------------------------------------------------
# Init
# ---------------------------------------------------------------------------
def initialize(bucket):

    global gpdb_host
    global email_sender
    global email_recipient
    global aws_region
    global script
    
    try:
        data = s3.get_object(Bucket=bucket, Key=config_dir + "sandbox_config.json")
        json_config = json.loads(data['Body'].read())
        pprint(json_config)
        gpdb_host = json_config["gpdb_master_host"]
        email_sender = json_config["email_sender"]
        email_recipient = json_config["email_recipient"]
        aws_region = json_config["aws_region"]
        script = json_config["script"]
    except Exception as e:
        print(e)
        print('Error getting sandbox_config object from bucket {}. Make sure it exists and your bucket is in the same region as this function.'.format(bucket))
        raise e

# ---------------------------------------------------------------------------
# Function to send mail
#
# How to send email is from:
# https://docs.aws.amazon.com/ses/latest/DeveloperGuide/send-using-sdk-python.html
# Had to add AmazonSESFullAccess to the role and had to verify email address from SES
# ---------------------------------------------------------------------------
def send_mail(bucket, key, rc, response):
    
    SENDER = email_sender
    RECIPIENT = email_recipient
    AWS_REGION = aws_region

    # The subject line for the email.
    if rc==0:
        SUBJECT = "SUCCESS: "
    else:
        SUBJECT = "FAILED: "
    SUBJECT += "Amazon S3 file upload on bucket " + bucket

    # The email body for recipients with non-HTML email clients.
    BODY_TEXT = ("File " + key + " was uploaded to S3 bucket " + bucket + "\r\n\r\n"
                 "Analytics auto enablement process returned with:\r\n" +
                 response)
    # The character encoding for the email.
    CHARSET = "UTF-8"

    # Create a new SES resource and specify a region.
    client = boto3.client('ses',region_name=AWS_REGION)

    # Try to send the email.
    try:
        #Provide the contents of the email.
        mail_response = client.send_email (
            Destination={
                'ToAddresses': [
                    RECIPIENT,
                ],
            },
            Message={
                'Body': {
                    'Text': {
                        'Charset': CHARSET,
                        'Data': BODY_TEXT,
                    },
                },
                'Subject': {
                    'Charset': CHARSET,
                    'Data': SUBJECT,
                },
            },
            Source=SENDER,
        )        
    # Display an error if something goes wrong. 
    except ClientError as e:
        print(e.mail_response['Error']['Message'])
        return -1
    else:
        print("Email sent! Message ID:"),
        print(mail_response['ResponseMetadata']['RequestId'])
        return 0
        
# ---------------------------------------------------------------------------
# Function to invoke remote script
#
# Code primarily from:
# https://aws.amazon.com/blogs/compute/scheduling-ssh-jobs-using-aws-lambda/
# ---------------------------------------------------------------------------
def invoke_script(bucket, key, timeout=30, bg_run=False): 
    
    s3.download_file(bucket, config_dir + 'PivotalAWS_lmugnano.pem', '/tmp/keyname.pem')
    head = s3.head_object(Bucket=bucket, Key=key)
    if 'dbtable' in head['Metadata']:
        dbtable = head['Metadata']['dbtable']
    else:
        dbtable = ''
        
    host=gpdb_host
    user='gpadmin'
    
    k = paramiko.RSAKey.from_private_key_file("/tmp/keyname.pem")
    c = paramiko.SSHClient()
    c.set_missing_host_key_policy(paramiko.AutoAddPolicy())

    #host=event['IP']
    print ("Connecting to " + host)
    c.connect( hostname = host, username = "gpadmin", pkey = k, timeout = 10 )
    print ("Connected to " + host)

    commands = [
        script
        ]
    for command in commands:
        print ("Executing {}".format(command))
        stdin , stdout, stderr = c.exec_command(command + " -s3_bucket '%s' -s3_key '%s'" % (bucket, key))
        rc = stdout.channel.recv_exit_status()
        stderr = stderr.read()
        vw_nm = stdout.read()
        if rc != 0:
            return rc, "FAILED: File upload failed with error:\r\n    " + stderr

    return rc, "SUCCESS: File uploaded and is available for reporting with view " + vw_nm
    
# ---------------------------------------------------------------------------
# Event Handler for S3 notification
# ---------------------------------------------------------------------------
def lambda_handler(event, context):
    #print("Received event: " + json.dumps(event, indent=2))

    # Get the object from the event 
    bucket = event['Records'][0]['s3']['bucket']['name']
    key = urllib.unquote_plus(event['Records'][0]['s3']['object']['key'].encode('utf8'))
    
    # Exit if file is part of config
    if key.startswith(config_dir):
        return ''
    
    try:
        response = s3.get_object(Bucket=bucket, Key=key)
    except Exception as e:
        print(e)
        print('Error getting object {} from bucket {}. Make sure they exist and your bucket is in the same region as this function.'.format(key, bucket))
        raise e   
    
    initialize(bucket)
    rc, script_response = invoke_script(bucket,key)
    send_mail(bucket,key,rc,script_response)
    
    # Return response
    return response['ContentType']

